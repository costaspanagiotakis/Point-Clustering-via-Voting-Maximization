function [ok] = plotClustering(Data,Clustering,tt)

ok = 1;
cmap = colormap(jet(128));
N = size(Data,1);
msize = 10;
figure;
for i=2:N,
    if i == 2 || length(find(Clustering(2:i-1) == Clustering(i))) == 0,
        myCol = 1+round(127*Clustering(i) / max(Clustering));
        c = cmap(myCol,1:3);
        if Clustering(i) == 1,
            plot(Data(i,1),Data(i,2),'s','Color',c,'MarkerSize',msize);
        elseif Clustering(i) == 2,
            plot(Data(i,1),Data(i,2),'+','Color',c,'MarkerSize',msize);
        elseif  Clustering(i) == 3,
            plot(Data(i,1),Data(i,2),'o','Color',c,'MarkerSize',msize);
        else 
            plot(Data(i,1),Data(i,2),'x','Color',c,'MarkerSize',msize);
        end
        hold on;
    end
end
legend('Cluster 1','Cluster 2', 'Cluster 3','Cluster 4');
hold on;

for i=1:N,
    myCol = 1+round(127*Clustering(i) / max(Clustering));
    c = cmap(myCol,1:3);
       if Clustering(i) == 1,
            plot(Data(i,1),Data(i,2),'s','Color',c,'MarkerSize',msize);
        elseif Clustering(i) == 2,
            plot(Data(i,1),Data(i,2),'+','Color',c,'MarkerSize',msize);
        elseif  Clustering(i) == 3,
            plot(Data(i,1),Data(i,2),'o','Color',c,'MarkerSize',msize);
        else
            plot(Data(i,1),Data(i,2),'x','Color',c,'MarkerSize',msize);
        end
    hold on;
   
    
    hold on;
end
title(tt);