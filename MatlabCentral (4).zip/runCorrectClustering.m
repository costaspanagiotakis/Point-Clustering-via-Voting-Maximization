%
% Local Maximization of VM optional step (CVR-LMV)
function [NewClustering] = runCorrectClustering(Data,sVot,Clustering)

N = length(Clustering);
C = max(Clustering);
FE = zeros(N,1);
Cent = zeros(C,N);
ClusterSizes = zeros(C,1);

for i=1:C,
    pos = find(Clustering == i);
    ClusterSizes(i) = length(pos);
    if length(pos) > 1,
        Cent(i,:) = sum(sVot(pos,1:N));  
    else
        Cent(i,:) = sVot(pos,1:N);  
    end
end

for i=1:N,
    FE(i) = Cent(Clustering(i),i);  % �_{i=1}^N �_{j \in C} V(j,i) / |C|    
    FE2(i) = Cent(Clustering(i),i) / ClusterSizes(Clustering(i)); 
end

[~,pos] = sort(FE2);
[VOL] = getError(Data,sVot,Clustering, 0);
NewClustering = Clustering;
ite = 0;
while 1,
    Changes = 0;
    fChanges = 0;

    for i=1:N,
        id = pos(i);
        cid = Clustering(id);
        if ClusterSizes(cid) == 1,
            continue;
        end
        
        gainMedian = -ones(C,1);
        gain = -ones(C,1);

        pos1 = Clustering == cid;
        a1M = sum(sVot(pos1,id)+sVot(id,pos1)');
        a1 = ClusterSizes(cid)*median(sVot(pos1,id)+sVot(id,pos1)');
        
     
      
        s1M = sum(Cent(cid,pos1));
        s1 = ClusterSizes(cid)*median(Cent(cid,pos1));
        for j=1:C,
            if j == cid,
                continue;
            end
            pos2 = Clustering == j;
            a2M = sum(sVot(pos2,id)+sVot(id,pos2)');
            a2 = ClusterSizes(j)*median(sVot(pos2,id)+sVot(id,pos2)');
            s2M = sum(Cent(j,pos2));
            s2 = ClusterSizes(j)*median(Cent(j,pos2));
            
            fp = (s1 / ClusterSizes(cid)) +  (s2 / ClusterSizes(j));
            fn = (s1-a1) / (ClusterSizes(cid)-1) + (s2+a2) / (ClusterSizes(j)+1);
            gainMedian(j) = fn-fp;
            fp = (s1M / ClusterSizes(cid)) +  (s2M / ClusterSizes(j));
            fn = (s1M-a1M) / (ClusterSizes(cid)-1) + (s2M+a2M) / (ClusterSizes(j)+1);
            gain(j) = fn-fp;
        end
        [tempMed, bcMed] = max(gainMedian);
        [temp, bc] = max(gain);

        if temp > 0 || (bc == bcMed && tempMed > 0 && tempMed + temp> 0),
            NewClustering(id) = bc;
           
                ClusterSizes(cid) = ClusterSizes(cid)-1;
                Clustering(id) = NewClustering(id);
                ClusterSizes(Clustering(id)) = ClusterSizes(Clustering(id))+1;
                Changes = Changes+1;
                Cent(cid,:) = Cent(cid,:) - sVot(id,:);
                Cent(bc,:) = Cent(bc,:) + sVot(id,:);
           
        end
    end
   
    ite = ite+1;
    if Changes <= 0 || ite > 10,
        break;
    end
end
    
Changes
    
    