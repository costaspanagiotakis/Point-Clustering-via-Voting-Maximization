close all;
clear all;

%Implemetation of Voting Clustering method CVR and CVR
% [1] C. Panagiotakis, Clustering via Voting Maximization, Journal of Classification, vol. 32, no. 2, pp. 212-240, 2015.
% [2] C. Panagiotakis and P. Fragopoulou, Voting Clustering and Key Points Selection, 
%International Conference on Computer Analysis of Images and Patterns, 2013

%load the dataset matrix (Data), number of clusters (NumClusters)

load iris.mat;%IRIS dataset see [1]
%load wine.mat;%WINE dataset see [1]

Thresh = 0.25;
toPlot = 0; %if toPlot == 1, it plots results for 2D data
Dist = zeros(N,N);


%Computation of Distance matrix
for i=1:N,
    u = Data(i,:);
    for j=i+1:N,
        v = Data(j,:);
        Dist(i,j) = norm(u-v);
        Dist(j,i) = Dist(i,j);
    end
end

[vot,Clustering,sVot] = getVotingMatrix(Data,Dist,NumClusters,Thresh,toPlot); %  CVR method   
[ClusteringC] = runCorrectClustering(Data,sVot,Clustering); % CVR-LMV method

%Performance metrics 
%ACC
[acc] = getAccuracy(GTClustering,Clustering);
[accC] = getAccuracy(GTClustering,ClusteringC);


%MSE [1]
[err] = getError(Data,sVot,Clustering,1);
[errC] = getError(Data,sVot,ClusteringC,1);

%voting error [1]
[errV_] = getError(Data,sVot,Clustering,0);
[errV_C] = getError(Data,sVot,ClusteringC,0);

%CS [1]
[errCS] = getError(Data,sVot,Clustering,2);
[errCSC] = getError(Data,sVot,ClusteringC,2);


if toPlot == 1,
    plotClustering(Data,GTClustering,'GT');
    plotClustering(Data,Clustering,'UCV');
    plotClustering(Data,ClusteringC,'UCV-C');
end

