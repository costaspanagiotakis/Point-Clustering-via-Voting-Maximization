% Ypologismos tou mesou sfalmatos MSE (an SSE = 1) alliws gia SSE  = 0 bgazei to voting
% error (SV)alliws gia SSE = 2 to CS measure 
% An SEE einai -1 upologizei th diaspora twn SE (VSE) 
% An SSE einai 3 bgazei to MVM measure (neo anti gia to VM)

function [err] = getError(Data,sVot,Clustering, SSE)

err = 0;

if SSE == -1,
    k = 0;
    vec = zeros(1,size(Data,1));
    for i=0:max(Clustering),
        pos = find(Clustering == i);
        if length(pos) > 1,
            m = mean(Data(pos,:));
            
            for j=1:length(pos),
                k = k+1;
                vec(k) = sum((Data(pos(j),:)-m).^2);
            end
        end
    end
    err = var(vec);
elseif SSE == 1,
    for i=0:max(Clustering),
        pos = find(Clustering == i);
        if length(pos) > 1,
            m = mean(Data(pos,:));
            
            for j=1:length(pos),
                err = err+sum((Data(pos(j),:)-m).^2);
            end
        end
    end
    err = err / size(Data,1);
elseif SSE == 3, %neo krithrio gia clustering testing sto ???Compound.data
    N = length(Clustering);
    C = max(Clustering);
    Cent = zeros(C,N);
    
    for i=1:C,
        pos = find(Clustering == i);
        if length(pos) > 1,
            Cent(i,:) = sqrt(sum(sVot(pos,1:N))) / length(pos);  %mean(sVot(pos,1:N)); 
        elseif length(pos) == 1
            Cent(i,:) = sVot(pos,1:N);  
        else
            Cent(i,:) = sVot(1,1:N);  
        end
    end
    
    for i=1:N,
        err = err+Cent(Clustering(i),i);  % �_{i=1}^N �_{j \in C} V(j,i) / |C|
    end                                   % �_{i=1}^N max_{j \in C} V(j,i) / |C|     
    err = err / (N);% err = err / C;
elseif SSE == 0,
    N = length(Clustering);
    C = max(Clustering);
    Cent = zeros(C,N);
    
    for i=1:C,
        pos = find(Clustering == i);
        if length(pos) > 1,
            Cent(i,:) = mean(sVot(pos,1:N));  %            Cent(i,:) = 0.5*mean(sVot(pos,1:N)+(sVot(1:N,pos)'));
        elseif length(pos) == 1
            Cent(i,:) = sVot(pos,1:N);  %           Cent(i,:) = 0.5*(sVot(pos,1:N)+sVot(1:N,pos)');
        else
            Cent(i,:) = sVot(1,1:N);  %           Cent(i,:) = 0.5*(sVot(pos,1:N)+sVot(1:N,pos)');
        end
    end
    
    for i=1:N,
        err = err+Cent(Clustering(i),i);  % �_{i=1}^N �_{j \in C} V(j,i) / |C|
    end
    err = err / C;
elseif SSE == 2,
    
    C = max(Clustering);
    Cent = zeros(C,size(Data,2));
    
    for i=1:C,
        pos = find(Clustering == i);
        if length(pos) > 1,
            Cent(i,:) = mean(Data(pos,:));
        end
    end
    d = 10000000000*ones(C,C);
    for i=1:C,
        for j=i+1:C,
            d(i,j) = norm(Cent(i,:)- Cent(j,:));
            d(j,i) = d(i,j);
        end
    end
    den = 0;
    for i=1:C,
        den = den + min(d(i,:));
    end
    
    for i=1:C,
        val = 0;
        pos = find(Clustering == i);
        d = zeros(length(pos),length(pos));
        for j=1:length(pos),
            for k=j+1:length(pos),
                d(j,k) = norm(Data(pos(j),:)- Data(pos(k),:) );
                d(k,j) = d(j,k);
            end
            val = val + max(d(j,:));
        end
        if ~isempty(pos),
            val = val/length(pos);
        end
        err = err + val;
    end
    err = err / den;
end



