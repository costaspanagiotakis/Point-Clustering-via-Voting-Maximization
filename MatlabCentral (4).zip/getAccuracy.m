%
%return the accuracy for clustering (C) where GT denotes the ground truth clustering
function [acc] = getAccuracy(GT,C)

N = length(GT);
Clusters = max(GT);
AccArray = zeros(Clusters,Clusters);

for i=1:Clusters,
    pos1 = find(GT == i);
    if ~isempty(pos1),
        for j=1:Clusters,
            pos2 = find(C == j);
            AccArray(i,j) = -length(intersect(pos1,pos2));
        end
    end
end

[~,Cost] = Hungarian(AccArray);

acc = -Cost / N;



%
%return the accuracy for clustering (C) where GT denotes the ground truth clustering
function [acc] = getAccuracyold(GT,C)

N = length(GT);
AccArray = zeros(N+1,N+1);
Clusters = max(GT);
vec = zeros((N+1)*(N+1),1);
k = 1;
for i=0:Clusters,
    pos1 = find(GT == i);
    if ~isempty(pos1),
        for j=0:Clusters,
            pos2 = find(C == j);
            AccArray(i+1,j+1) = length(intersect(pos1,pos2));
            vec(k) = AccArray(i+1,j+1);
            k = k+1;
        end
    else
        for j=0:Clusters,
            vec(k) = 0;
            k = k+1;
        end
    end
end

acc = 0;
while 1,
    [val,pos] = max(vec);
    vec(pos) = 0;
    [u,v] = find(AccArray == val);
    if isempty(u),
        continue;
    elseif val == 0,
        break;
    end
    u = u(1);
    v = v(1);
    AccArray(u,:) = 0;
    AccArray(:,v) = 0;
    acc = acc+val;
end

acc = acc / N;

% N = length(GT);
% Clusters = max(GT);
% tf = 0;
% 
% for i=0:Clusters,
%     pos = find(GT == i);
%     if ~isempty(pos),
%         v = median(C(pos));
%         tf = tf + sum(ismember(C(pos), v));
%     end
% end
% 
% acc = tf / N;