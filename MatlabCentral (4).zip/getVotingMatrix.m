%  CVR method  
%Clustering: final clustering
%Vot: Voting descriptor 
%s: voting matrix 
%set: Initial Centers 
function [vot,Clustering,s,set] = getVotingMatrix(Data,Dist,NumClusters,Thresh,toPlot)

N = size(Dist,1);
vot = zeros(N,1);
svot = zeros(N,1);
s = zeros(N,N);
for i=1:N,
   
    for j=1:N,
        if i ~= j
            w = 1/(0.00000001+Dist(i,j));
            s(j,i) = w;
        end
    end
    sw = sum(s(:,i));

        [~,pos] = find((s(:,i)'/sw)-0.5 > 0);
        if ~isempty(pos),
            for iid=1:4,
                s(pos,i) = 0.5*sw; 
                cs = sum(s(:,i))/sw;
                s(:,i) = s(:,i)*(1/cs);
            end

        end
    for j=1:N,
        if i ~= j
            s(j,i) = s(j,i) / sw;
            vot(j) = vot(j)+s(j,i);
            svot(i) = svot(i) + s(j,i);
        end
    end
end


[set,~,~,Clustering,~] = getCentersandClustering(vot,s,NumClusters,Thresh);


if toPlot == 1,
    cmap = colormap(jet(128));
    figure;
    maxVOT = max(vot);
    minVOT = min(vot);
    
    [temp, pos] = sort(vot,'descend');
    for i=1:N,
        v = vot(i);
        myCol = 1+round(127*(v - minVOT) / (maxVOT-minVOT));
        c = cmap(myCol,1:3);
        hold on;
        plot(Data(i,1),Data(i,2),'.','Color',c);
    end
    for i=1:N,        
        v = vot(i);
        myCol = 1+round(127*(v - minVOT) / (maxVOT-minVOT));
        c = cmap(myCol,1:3);
        
        if max(ismember(set , i)) == 1,
            plot(Data(i,1),Data(i,2),'o','Color',c);
            text(Data(i,1),Data(i,2),sprintf('%.2f',v));
        end
    end
end


%
%Initial centers computation (set)
function [set,vals,ite] = getCentroids(vot,s,NumClusters,Thresh)

set = zeros(1,20);
vals = zeros(1,20);
gvot = vot;
N = length(vot);
ite = 0;

if NumClusters == 1,
     while 1,
        [temp,id] = max(gvot);
        if ite >= 2 && temp < Thresh,
            break;
        end
        ite = ite+1;
        set(ite) = id;
        vals(ite) = gvot(id);
        
        for i=1:N,
            id1 = id;
            w = (s(i,id1)/vot(id1)) + (s(id1,i)/vot(i));
            
            val2 = 1/w;
            
            if ite == 1,
                gvot(i) = val2;  
            else
                gvot(i) = min(gvot(i),val2); 
            end
           
        end
        gvot(id) = -1000;
    end
else
    while 1,
        [~,id] = max(gvot);
        
        ite = ite+1;
        set(ite) = id;
        vals(ite) = gvot(id);
        
        for i=1:N,

            id1 = id;
            w = (s(i,id1)/vot(id1)) + (s(id1,i)/vot(i));
            
            val2 = 1/w;
            
            
            if ite == 1,
                gvot(i) = val2;  
            else
                gvot(i) = min(gvot(i),val2);  
          
            end
        end
        gvot(id) = -1000;

        if ite == NumClusters,
            break;
        end
    end
end

set = set(1:ite);
vals = vals(1:ite);


function [set,vals,Clusters,Clustering,ClusterSizes] = getCentersandClustering(vot,s,NumClusters,Thresh)

N = length(vot);
[set,vals,ite] = getCentroids(vot,s,NumClusters,Thresh); 

% Clustering method (NN)%
%


Clustering = zeros(N,1);
Clusters = zeros(ite,N);
ClusterSizes = zeros(ite,1);

for i=1:N,
    pos = find(set == i);
    if ~isempty(pos),
        Clustering(i) = pos;
        continue;
    end
    vec = 0.5*(s(set,i)+s(i,set)'); 
    [~,pos] = max(vec);
    Clustering(i) = pos;
end

for i=1:ite,
    pos = find(Clustering == i);
    Clusters(i,1:length(pos)) = pos;
    ClusterSizes(i) = length(pos);
end




